
print("Please enter the values")
name=input("What is your name? ")
print("Thanks " + name)
age=input("What is your age? ")
print(name + " is " + age + " years old" )
item1=input("Cost of Item 1 ") 
item2=input("Cost of Item 2 ")
print("The item 1 is " + item1 + " and item 2 is " + item2)

