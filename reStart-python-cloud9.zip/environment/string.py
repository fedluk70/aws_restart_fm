
myString="This is an example of String"
print(myString)
print(type(myString))
myValue=10
print(myString + " is of the datatype " + str(type(myString)) + " " + str(myValue) + " is of the datatype " + str(type(myValue)))
fName="Disha"
lName=" Kamra"
fullName=fName+lName
print(fullName)
fNumb=11
sNumb=12
tNumb=fNumb+sNumb
print(tNumb)
