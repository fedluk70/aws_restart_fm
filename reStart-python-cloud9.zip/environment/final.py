
name = input("What is your name? ")
color = input("What is your fav color? ")
animal = input("What is your fav animal? ")
print(name + ", you like " + color + " " + animal + "!")
print("==============================================")
print("{}, you like a {} {}!".format(color,name,animal))
